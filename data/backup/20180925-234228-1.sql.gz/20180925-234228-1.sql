-- -----------------------------
-- MySQL Data Transfer
--
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : eacoophp
--
-- Part : #1
-- Date : 2018-09-25 23:42:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `eacoo_action`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_action`;
CREATE TABLE `eacoo_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(30) NOT NULL COMMENT '行为唯一标识（组合控制器名+操作名）',
  `depend_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '来源类型。0系统,1module，2plugin，3theme',
  `depend_flag` varchar(16) NOT NULL DEFAULT '' COMMENT '所属模块名',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` varchar(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` varchar(255) NOT NULL DEFAULT '' COMMENT '行为规则',
  `log` varchar(255) NOT NULL DEFAULT '' COMMENT '日志规则',
  `action_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '执行类型。1自定义操作，2记录操作',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态。0禁用，1启用',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `eacoo_action`
-- -----------------------------
INSERT INTO `eacoo_action` VALUES ('1', 'login_index', '1', 'admin', '登录后台', '用户登录后台', '', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1383285551', '1383285551', '1');
INSERT INTO `eacoo_action` VALUES ('2', 'update_config', '1', 'admin', '更新配置', '新增或修改或删除配置', '', '', '2', '1383294988', '1383294988', '1');
INSERT INTO `eacoo_action` VALUES ('3', 'update_channel', '1', 'admin', '更新导航', '新增或修改或删除导航', '', '', '2', '1383296301', '1383296301', '1');
INSERT INTO `eacoo_action` VALUES ('4', 'update_category', '1', 'admin', '更新分类', '新增或修改或删除分类', '', '', '2', '1383296765', '1383296765', '1');
INSERT INTO `eacoo_action` VALUES ('5', 'database_export', '1', 'admin', '数据库备份', '后台进行数据库备份操作', '', '', '1', '0', '0', '1');
INSERT INTO `eacoo_action` VALUES ('6', 'database_optimize', '1', 'admin', '数据表优化', '数据库管理-》数据表优化', '', '', '1', '0', '0', '1');
INSERT INTO `eacoo_action` VALUES ('7', 'database_repair', '1', 'admin', '数据表修复', '数据库管理-》数据表修复', '', '', '1', '0', '0', '1');
INSERT INTO `eacoo_action` VALUES ('8', 'database_delbackup', '1', 'admin', '备份文件删除', '数据库管理-》备份文件删除', '', '', '1', '0', '0', '1');
INSERT INTO `eacoo_action` VALUES ('9', 'database_import', '1', 'admin', '数据库完成', '数据库管理-》数据还原', '', '', '1', '0', '0', '1');
INSERT INTO `eacoo_action` VALUES ('10', 'delete_actionlog', '1', 'admin', '删除行为日志', '后台删除用户行为日志', '', '', '1', '0', '0', '1');
INSERT INTO `eacoo_action` VALUES ('11', 'user_register', '1', 'admin', '注册', '', '', '', '1', '1506262430', '1506262430', '1');
INSERT INTO `eacoo_action` VALUES ('12', 'action_add', '1', 'admin', '添加行为', '', '', '', '1', '0', '0', '1');
INSERT INTO `eacoo_action` VALUES ('13', 'action_edit', '1', 'admin', '编辑用户行为', '', '', '', '1', '0', '0', '1');
INSERT INTO `eacoo_action` VALUES ('14', 'action_dellog', '1', 'admin', '清空日志', '清空所有行为日志', '', '', '1', '0', '1518006312', '1');
INSERT INTO `eacoo_action` VALUES ('15', 'setstatus', '1', 'admin', '改变数据状态', '通过列表改变了数据的status状态值', '', '', '1', '0', '1518004873', '1');
INSERT INTO `eacoo_action` VALUES ('16', 'modules_delapp', '1', 'admin', '删除模块', '删除整个模块的时候记录', '', '', '2', '1520222797', '1520225057', '1');

-- -----------------------------
-- Table structure for `eacoo_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_action_log`;
CREATE TABLE `eacoo_action_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL COMMENT '行为ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `nickname` varchar(60) NOT NULL DEFAULT '' COMMENT '用户名',
  `request_method` varchar(20) NOT NULL DEFAULT '' COMMENT '请求类型',
  `url` varchar(120) NOT NULL DEFAULT '' COMMENT '操作页面',
  `data` varchar(300) NOT NULL DEFAULT '0' COMMENT '相关数据,json格式',
  `ip` varchar(18) NOT NULL COMMENT 'IP',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `user_agent` varchar(360) NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='行为日志表';

-- -----------------------------
-- Records of `eacoo_action_log`
-- -----------------------------
INSERT INTO `eacoo_action_log` VALUES ('1', '6', '1', 'admin', 'POST', '/admin.php/admin/database/optimize.html', '{\"param\":[]}', '127.0.0.1', '数据表优化', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1531549801');
INSERT INTO `eacoo_action_log` VALUES ('2', '7', '1', 'admin', 'POST', '/admin.php/admin/database/repair.html', '{\"param\":[]}', '127.0.0.1', '数据表修复', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1531549805');
INSERT INTO `eacoo_action_log` VALUES ('3', '13', '1', 'admin', 'GET', '/admin.php/admin/action/edit.html', '{\"param\":[]}', '127.0.0.1', '编辑用户行为', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1531929846');
INSERT INTO `eacoo_action_log` VALUES ('4', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533833086');
INSERT INTO `eacoo_action_log` VALUES ('5', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/micro_topics.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533833320');
INSERT INTO `eacoo_action_log` VALUES ('6', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533833325');
INSERT INTO `eacoo_action_log` VALUES ('7', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533833330');
INSERT INTO `eacoo_action_log` VALUES ('8', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533833438');
INSERT INTO `eacoo_action_log` VALUES ('9', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533833559');
INSERT INTO `eacoo_action_log` VALUES ('10', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533833870');
INSERT INTO `eacoo_action_log` VALUES ('11', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533833874');
INSERT INTO `eacoo_action_log` VALUES ('12', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834086');
INSERT INTO `eacoo_action_log` VALUES ('13', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834088');
INSERT INTO `eacoo_action_log` VALUES ('14', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834092');
INSERT INTO `eacoo_action_log` VALUES ('15', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/querylist.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834287');
INSERT INTO `eacoo_action_log` VALUES ('16', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834289');
INSERT INTO `eacoo_action_log` VALUES ('17', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834291');
INSERT INTO `eacoo_action_log` VALUES ('18', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834374');
INSERT INTO `eacoo_action_log` VALUES ('19', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834378');
INSERT INTO `eacoo_action_log` VALUES ('20', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834379');
INSERT INTO `eacoo_action_log` VALUES ('21', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834468');
INSERT INTO `eacoo_action_log` VALUES ('22', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834471');
INSERT INTO `eacoo_action_log` VALUES ('23', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834558');
INSERT INTO `eacoo_action_log` VALUES ('24', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834607');
INSERT INTO `eacoo_action_log` VALUES ('25', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834644');
INSERT INTO `eacoo_action_log` VALUES ('26', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834654');
INSERT INTO `eacoo_action_log` VALUES ('27', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834979');
INSERT INTO `eacoo_action_log` VALUES ('28', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533834983');
INSERT INTO `eacoo_action_log` VALUES ('29', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/wechat.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533835015');
INSERT INTO `eacoo_action_log` VALUES ('30', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1533835020');
INSERT INTO `eacoo_action_log` VALUES ('31', '1', '1', 'admin', 'POST', '/admin.php/admin/login/index.html', '{\"param\":[]}', '127.0.0.1', '登录后台', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1534067407');
INSERT INTO `eacoo_action_log` VALUES ('32', '1', '1', 'admin', 'POST', '/admin.php/admin/login/index.html', '{\"param\":[]}', '127.0.0.1', '登录后台', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1534088896');
INSERT INTO `eacoo_action_log` VALUES ('33', '15', '1', 'admin', 'GET', '/admin.php/admin/attachment/setstatus/status/recycle/ids/13.html?model=Attachment', '{\"param\":{\"model\":\"Attachment\"}}', '127.0.0.1', '改变数据状态', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1534175899');
INSERT INTO `eacoo_action_log` VALUES ('34', '16', '1', 'admin', 'GET', '/admin.php/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1534346568');
INSERT INTO `eacoo_action_log` VALUES ('35', '1', '1', 'admin', 'GET', '/admin.php?s=/admin/login/index', '{\"param\":[]}', '127.0.0.1', '登录后台', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1534822933');
INSERT INTO `eacoo_action_log` VALUES ('36', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1534868738');
INSERT INTO `eacoo_action_log` VALUES ('37', '15', '1', 'admin', 'POST', '/admin.php?s=/admin/link/setstatus/status/forbid.html&model=Links', '{\"param\":{\"model\":\"Links\"}}', '127.0.0.1', '改变数据状态', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1534869192');
INSERT INTO `eacoo_action_log` VALUES ('38', '15', '1', 'admin', 'POST', '/admin.php?s=/admin/link/setstatus/status/resume.html&model=Links', '{\"param\":{\"model\":\"Links\"}}', '127.0.0.1', '改变数据状态', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1534869198');
INSERT INTO `eacoo_action_log` VALUES ('39', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1535256293');
INSERT INTO `eacoo_action_log` VALUES ('40', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1535256661');
INSERT INTO `eacoo_action_log` VALUES ('41', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1535257191');
INSERT INTO `eacoo_action_log` VALUES ('42', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1535257238');
INSERT INTO `eacoo_action_log` VALUES ('43', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1535257275');
INSERT INTO `eacoo_action_log` VALUES ('44', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1535259387');
INSERT INTO `eacoo_action_log` VALUES ('45', '1', '1', 'admin', 'POST', '/admin.php?s=/admin/login/index.html', '{\"param\":[]}', '127.0.0.1', '登录后台', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1535807146');
INSERT INTO `eacoo_action_log` VALUES ('46', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1535807423');
INSERT INTO `eacoo_action_log` VALUES ('47', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/cms.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1536077513');
INSERT INTO `eacoo_action_log` VALUES ('48', '16', '1', 'admin', 'GET', '/admin.php?s=/admin/modules/delapp/name/micro_topics.html', '{\"param\":[]}', '127.0.0.1', '删除模块', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1536077639');
INSERT INTO `eacoo_action_log` VALUES ('49', '13', '1', 'admin', 'GET', '/admin.php?s=/admin/action/edit.html', '{\"param\":[]}', '127.0.0.1', '编辑用户行为', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1536422766');
INSERT INTO `eacoo_action_log` VALUES ('50', '13', '1', 'admin', 'GET', '/admin.php?s=/admin/action/edit.html', '{\"param\":[]}', '127.0.0.1', '编辑用户行为', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1536423037');
INSERT INTO `eacoo_action_log` VALUES ('51', '13', '1', 'admin', 'GET', '/admin.php?s=/admin/action/edit.html', '{\"param\":[]}', '127.0.0.1', '编辑用户行为', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1536423216');
INSERT INTO `eacoo_action_log` VALUES ('52', '13', '1', 'admin', 'GET', '/admin.php?s=/admin/action/edit.html', '{\"param\":[]}', '127.0.0.1', '编辑用户行为', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1536423321');
INSERT INTO `eacoo_action_log` VALUES ('53', '13', '1', 'admin', 'GET', '/admin.php?s=/admin/action/edit.html', '{\"param\":[]}', '127.0.0.1', '编辑用户行为', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1536423344');
INSERT INTO `eacoo_action_log` VALUES ('54', '1', '1', 'admin', 'POST', '/admin.php?s=/admin/login/index.html', '{\"param\":[]}', '127.0.0.1', '登录后台', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15', '1536763049');
INSERT INTO `eacoo_action_log` VALUES ('55', '1', '1', 'admin', 'POST', '/admin.php?s=/admin/login/index.html', '{\"param\":[]}', '127.0.0.1', '登录后台', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0 Safari/605.1.15', '1537285091');
INSERT INTO `eacoo_action_log` VALUES ('56', '5', '1', 'admin', 'POST', '/admin.php?s=/admin/database/export.html', '{\"param\":[]}', '127.0.0.1', '数据库备份', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0 Safari/605.1.15', '1537890148');
INSERT INTO `eacoo_action_log` VALUES ('57', '5', '1', 'admin', 'GET', '/admin.php?s=/admin/database/export.html&id=0&start=0', '{\"param\":{\"id\":\"0\",\"start\":\"0\"}}', '127.0.0.1', '数据库备份', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0 Safari/605.1.15', '1537890148');

-- -----------------------------
-- Table structure for `eacoo_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_attachment`;
CREATE TABLE `eacoo_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'UID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '文件名',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '文件路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件链接（暂时无用）',
  `location` varchar(15) NOT NULL DEFAULT '' COMMENT '文件存储位置(或驱动)',
  `path_type` varchar(20) DEFAULT 'picture' COMMENT '路径类型，存储在uploads的哪个目录中',
  `ext` char(4) NOT NULL DEFAULT '' COMMENT '文件类型',
  `mime_type` varchar(60) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `alt` varchar(255) DEFAULT NULL COMMENT '替代文本图像alt',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件sha1编码',
  `download` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` mediumint(8) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_paty_type` (`path_type`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8 COMMENT='附件表';

-- -----------------------------
-- Records of `eacoo_attachment`
-- -----------------------------
INSERT INTO `eacoo_attachment` VALUES ('1', '1', 'preg_match_imgs.jpeg', '/uploads/Editor/Picture/2016-06-12/575d4bd8d0351.jpeg', '', 'local', 'editor', 'jpeg', '', '19513', '', '4cf157e42b44c95d579ee39b0a1a48a4', 'dee76e7b39f1afaad14c1e03cfac5f6031c3c511', '0', '1465732056', '1465732056', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('2', '1', 'gerxiangimg200x200.jpg', '/uploads/Editor/Picture/2016-06-12/575d4bfb09961.jpg', '', 'local', 'editor', 'jpg', '', '5291', 'gerxiangimg200x200', '4db879c357c4ab80c77fce8055a0785f', '480eb2e097397856b99b373214fb28c2f717dacf', '0', '1465732090', '1465732090', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('3', '1', 'oraclmysqlzjfblhere.jpg', '/uploads/Editor/Picture/2016-06-12/575d4c691e976.jpg', '', 'local', 'editor', 'jpg', '', '23866', 'mysql', '5a3a5a781a6d9b5f0089f6058572f850', 'a17bfe395b29ba06ae5784486bcf288b3b0adfdb', '0', '1465732201', '1465732201', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('4', '1', 'logo.png', '/logo.png', '', 'local', 'picture', 'jpg', '', '40000', 'eacoophp-logo', '', '', '0', '1465732201', '1465732201', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('6', '1', '功能表格', '/uploads/file/2016-07-13/5785daaa2f2e6.xlsx', '', 'local', 'file', 'xlsx', '', '11399', '', '5fd89f172ca8a95fa13b55ccb24d5971', 'b8706af3fa59ef0fc65675e40131f25e12f94664', '0', '1468390058', '1468390058', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('8', '1', '会员数据2016-06-30 18_44_14', '/uploads/file/2016-07-13/5785dce2e15c1.xls', '', 'local', 'file', 'xls', '', '173387', '', '9ff55acddd75366d20dcb931eb1d87ea', 'acf5daf769e6ba06854002104bfb8c2886da97af', '0', '1468390626', '1468390626', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('10', '1', '苹果短信-三全音 - 铃声', '/uploads/file/2016-07-27/579857b5aca95.mp3', '', 'local', 'file', 'mp3', '', '19916', '', 'bab00edb8d6a5cf4de5444a2e5c05009', '73cda0fb4f947dcb496153d8b896478af1247935', '0', '1469601717', '1469601717', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('12', '1', 'music', '/uploads/file/2016-07-28/57995fe9bf0da.mp3', '', 'local', 'file', 'mp3', '', '160545', '', '935cd1b8950f1fdcd23d47cf791831cf', '73c318221faa081544db321bb555148f04b61f00', '0', '1469669353', '1469669353', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('13', '1', '7751775467283337', '/uploads/picture/2016-09-26/57e8dc9d29b01.jpg', '', 'local', 'picture', 'jpg', '', '70875', '', '3e3bfc950aa0b6ebb56654c15fe8e392', 'c75e70753eaf36aaee10efb3682fdbd8f766d32d', '0', '1474878621', '1474878621', '99', '-1');
INSERT INTO `eacoo_attachment` VALUES ('14', '1', '4366486814073822', '/uploads/picture/2016-09-26/57e8ddebaafff.jpg', '', 'local', 'picture', 'jpg', '', '302678', '', 'baf2dc5ea7b80a6d73b20a2c762aec1e', 'd73fe63f5c179135b2c2e7f174d6df36e05ab3d8', '0', '1474878955', '1474878955', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('15', '1', 'wx1image_14751583274385', '/uploads/picture/2016-09-29/wx1image_14751583274385.jpg', '', 'local', 'picture', 'jpg', '', '311261', '', '', '', '0', '1475158327', '1475158327', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('17', '1', 'wx1image_14751583287356', '/uploads/picture/2016-09-29/wx1image_14751583287356.jpg', '', 'local', 'picture', 'jpg', '', '43346', '', '', '', '0', '1475158328', '1475158328', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('18', '1', 'wx1image_14751583293547', '/uploads/picture/2016-09-29/wx1image_14751583293547.jpg', '', 'local', 'picture', 'jpg', '', '150688', '', '', '', '0', '1475158329', '1475158329', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('19', '1', 'wx1image_14751583298683', '/uploads/picture/2016-09-29/wx1image_14751583298683.jpg', '', 'local', 'picture', 'jpg', '', '79626', '', '', '', '0', '1475158329', '1475158329', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('20', '1', 'wx1image_14751583294128', '/uploads/picture/2016-09-29/wx1image_14751583294128.jpg', '', 'local', 'picture', 'jpg', '', '61008', '', '', '', '0', '1475158329', '1475158329', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('21', '1', 'wx1image_14751583302886', '/uploads/picture/2016-09-29/wx1image_14751583302886.jpg', '', 'local', 'picture', 'jpg', '', '20849', '', '', '', '0', '1475158330', '1475158330', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('22', '1', 'wx1image_1475158330831', '/uploads/picture/2016-09-29/wx1image_1475158330831.jpg', '', 'local', 'picture', 'jpg', '', '56265', '', '', '', '0', '1475158330', '1475158330', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('23', '1', 'wx1image_1475158330180', '/uploads/picture/2016-09-29/wx1image_1475158330180.jpg', '', 'local', 'picture', 'jpg', '', '121610', '', '', '', '0', '1475158330', '1475158330', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('24', '1', 'wx1image_14751583318180', '/uploads/picture/2016-09-29/wx1image_14751583318180.jpg', '', 'local', 'picture', 'jpg', '', '35555', '', '', '', '0', '1475158331', '1475158331', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('25', '1', 'wx1image_1475158332231', '/uploads/picture/2016-09-29/wx1image_1475158332231.jpg', '', 'local', 'picture', 'jpg', '', '32095', '', '', '', '0', '1475158332', '1475158332', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('26', '1', 'wx1image_14751583325255', '/uploads/picture/2016-09-29/wx1image_14751583325255.jpg', '', 'local', 'picture', 'jpg', '', '70088', '', '', '', '0', '1475158332', '1475158332', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('27', '1', 'wx1image_14751583331037', '/uploads/picture/2016-09-29/wx1image_14751583331037.jpg', '', 'local', 'picture', 'jpg', '', '37085', '', '', '', '0', '1475158333', '1475158333', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('28', '1', 'wx1image_14751583343169', '/uploads/picture/2016-09-29/wx1image_14751583343169.jpg', '', 'local', 'picture', 'jpg', '', '65279', '', '', '', '0', '1475158334', '1475158334', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('29', '1', 'wx1image_14751583344810', '/uploads/picture/2016-09-29/wx1image_14751583344810.jpg', '', 'local', 'picture', 'jpg', '', '83936', '', '', '', '0', '1475158334', '1475158334', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('30', '1', 'wx1image_14751583356369', '/uploads/picture/2016-09-29/wx1image_14751583356369.jpg', '', 'local', 'picture', 'jpg', '', '20032', '', '', '', '0', '1475158335', '1475158335', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('31', '1', 'wx1image_14751583359328', '/uploads/picture/2016-09-29/wx1image_14751583359328.jpg', '', 'local', 'picture', 'jpg', '', '53984', '', '', '', '0', '1475158335', '1475158335', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('32', '1', 'wx1image_1475158335689', '/uploads/picture/2016-09-29/wx1image_1475158335689.jpg', '', 'local', 'picture', 'jpg', '', '50399', '', '', '', '0', '1475158335', '1475158335', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('33', '1', 'wx1image_14751583361694', '/uploads/picture/2016-09-29/wx1image_14751583361694.jpg', '', 'local', 'picture', 'jpg', '', '128125', '', '', '', '0', '1475158336', '1475158336', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('34', '1', 'wx1image_14751583371210', '/uploads/picture/2016-09-29/wx1image_14751583371210.jpg', '', 'local', 'picture', 'jpg', '', '35090', '', '', '', '0', '1475158337', '1475158337', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('36', '1', 'wx1image_14751583393940', '/uploads/picture/2016-09-29/wx1image_14751583393940.jpg', '', 'local', 'picture', 'jpg', '', '74827', '', '', '', '0', '1475158339', '1475158339', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('38', '1', 'wx1image_14751587991531', '/uploads/picture/2016-09-29/wx1image_14751587991531.jpg', '', 'local', 'picture', 'jpg', '', '154175', '', '', '', '0', '1475158799', '1475158799', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('39', '1', 'wx1image_14751587997094.png', '/uploads/picture/2016-09-29/wx1image_14751587997094.png', '', 'local', 'picture', 'jpg', '', '26583', '', '', '', '0', '1475158799', '1475158799', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('40', '1', 'wx1image_14751587995130', '/uploads/picture/2016-09-29/wx1image_14751587995130.jpg', '', 'local', 'picture', 'jpg', '', '23625', '', '', '', '0', '1475158799', '1475158799', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('41', '1', 'wx1image_14751587995676', '/uploads/picture/2016-09-29/wx1image_14751587995676.jpg', '', 'local', 'picture', 'jpg', '', '67232', '', '', '', '0', '1475158799', '1475158799', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('43', '1', 'wx1image_14751588004786', '/uploads/picture/2016-09-29/wx1image_14751588004786.jpg', '', 'local', 'picture', 'jpg', '', '26779', '', '', '', '0', '1475158800', '1475158800', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('44', '1', 'wx1image_14751588009825', '/uploads/picture/2016-09-29/wx1image_14751588009825.jpg', '', 'local', 'picture', 'jpg', '', '7546', '', '', '', '0', '1475158800', '1475158800', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('45', '1', 'wx1image_1475158800631', '/uploads/picture/2016-09-29/wx1image_1475158800631.jpg', '', 'local', 'picture', 'jpg', '', '10713', '', '', '', '0', '1475158800', '1475158800', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('46', '1', 'wx1image_14751588008193', '/uploads/picture/2016-09-29/wx1image_14751588008193.jpg', '', 'local', 'picture', 'jpg', '', '94825', '', '', '', '0', '1475158800', '1475158800', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('47', '1', 'wx1image_14751588004666', '/uploads/picture/2016-09-29/wx1image_14751588004666.jpg', '', 'local', 'picture', 'jpg', '', '39592', '', '', '', '0', '1475158800', '1475158800', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('48', '1', 'wx1image_14751588008768.png', '/uploads/picture/2016-09-29/wx1image_14751588008768.png', '', 'local', 'picture', 'jpg', '', '50732', '', '', '', '0', '1475158800', '1475158800', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('49', '1', 'wx1image_1475158800354.png', '/uploads/picture/2016-09-29/wx1image_1475158800354.png', '', 'local', 'picture', 'jpg', '', '21937', '', '', '', '0', '1475158800', '1475158800', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('50', '1', 'wx1image_1475158801542.png', '/uploads/picture/2016-09-29/wx1image_1475158801542.png', '', 'local', 'picture', 'jpg', '', '19383', '', '', '', '0', '1475158801', '1475158801', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('51', '1', 'wx1image_14751588012312.png', '/uploads/picture/2016-09-29/wx1image_14751588012312.png', '', 'local', 'picture', 'jpg', '', '45798', '', '', '', '0', '1475158801', '1475158801', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('52', '1', 'wx1image_14751588058806', '/uploads/picture/2016-09-29/wx1image_14751588058806.jpg', '', 'local', 'picture', 'jpg', '', '24855', '', '', '', '0', '1475158805', '1475158805', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('53', '1', 'wx1image_14751588067284', '/uploads/picture/2016-09-29/wx1image_14751588067284.jpg', '', 'local', 'picture', 'jpg', '', '14851', '', '', '', '0', '1475158806', '1475158806', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('54', '1', 'wx1image_14751588091783.png', '/uploads/picture/2016-09-29/wx1image_14751588091783.png', '', 'local', 'picture', 'jpg', '', '68781', '', '', '', '0', '1475158809', '1475158809', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('55', '1', 'wx1image_14751588108673.png', '/uploads/picture/2016-09-29/wx1image_14751588108673.png', '', 'local', 'picture', 'jpg', '', '13649', '', '', '', '0', '1475158810', '1475158810', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('56', '1', 'wx1image_14751588114626.png', '/uploads/picture/2016-09-29/wx1image_14751588114626.png', '', 'local', 'picture', 'jpg', '', '10724', '', '', '', '0', '1475158811', '1475158811', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('57', '1', 'wx1image_14751588116216.png', '/uploads/picture/2016-09-29/wx1image_14751588116216.png', '', 'local', 'picture', 'jpg', '', '18955', '', '', '', '0', '1475158811', '1475158811', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('58', '1', 'wx1image_14751588117971', '/uploads/picture/2016-09-29/wx1image_14751588117971.jpg', '', 'local', 'picture', 'jpg', '', '34171', '', '', '', '0', '1475158811', '1475158811', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('59', '1', 'wx1image_14751588113400', '/uploads/picture/2016-09-29/wx1image_14751588113400.jpg', '', 'local', 'picture', 'jpg', '', '16445', '', '', '', '0', '1475158811', '1475158811', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('60', '1', 'wx1image_14751588113547', '/uploads/picture/2016-09-29/wx1image_14751588113547.jpg', '', 'local', 'picture', 'jpg', '', '7062', '', '', '', '0', '1475158811', '1475158811', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('61', '1', 'wx1image_14751588111003', '/uploads/picture/2016-09-29/wx1image_14751588111003.jpg', '', 'local', 'picture', 'jpg', '', '7982', '', '', '', '0', '1475158811', '1475158811', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('62', '1', 'wx1image_14751588185564.png', '/uploads/picture/2016-09-29/wx1image_14751588185564.png', '', 'local', 'picture', 'jpg', '', '163203', '', '', '', '0', '1475158818', '1475158818', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('63', '1', 'wx1image_14751588213497.png', '/uploads/picture/2016-09-29/wx1image_14751588213497.png', '', 'local', 'picture', 'jpg', '', '14153', '', '', '', '0', '1475158821', '1475158821', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('64', '1', 'wx1image_14751588212612.png', '/uploads/picture/2016-09-29/wx1image_14751588212612.png', '', 'local', 'picture', 'jpg', '', '15962', '', '', '', '0', '1475158821', '1475158821', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('65', '1', 'wx1image_14751588215121.png', '/uploads/picture/2016-09-29/wx1image_14751588215121.png', '', 'local', 'picture', 'jpg', '', '22820', '', '', '', '0', '1475158821', '1475158821', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('67', '1', 'wx1image_14751588223870', '/uploads/picture/2016-09-29/wx1image_14751588223870.jpg', '', 'local', 'picture', 'jpg', '', '31690', '', '', '', '0', '1475158822', '1475158822', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('68', '1', 'wx1image_14751588235543.png', '/uploads/picture/2016-09-29/wx1image_14751588235543.png', '', 'local', 'picture', 'jpg', '', '32383', '', '', '', '0', '1475158823', '1475158823', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('69', '1', 'wx1image_14751588233114.png', '/uploads/picture/2016-09-29/wx1image_14751588233114.png', '', 'local', 'picture', 'jpg', '', '16871', '', '', '', '0', '1475158823', '1475158823', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('70', '1', 'wx1image_14751588247501.png', '/uploads/picture/2016-09-29/wx1image_14751588247501.png', '', 'local', 'picture', 'jpg', '', '48306', '', '', '', '0', '1475158824', '1475158824', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('73', '1', 'wx1image_1475158835506', '/uploads/picture/2016-09-29/wx1image_1475158835506.jpg', '', 'local', 'picture', 'jpg', '', '12805', '', '', '', '0', '1475158835', '1475158835', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('74', '1', 'wx1image_14751588359605.png', '/uploads/picture/2016-09-29/wx1image_14751588359605.png', '', 'local', 'picture', 'jpg', '', '42306', '', '', '', '0', '1475158835', '1475158835', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('75', '1', 'wx1image_14751588351768.png', '/uploads/picture/2016-09-29/wx1image_14751588351768.png', '', 'local', 'picture', 'jpg', '', '13828', '', '', '', '0', '1475158835', '1475158835', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('76', '1', 'wx1image_14751588383783.png', '/uploads/picture/2016-09-29/wx1image_14751588383783.png', '', 'local', 'picture', 'jpg', '', '39390', '', '', '', '0', '1475158838', '1475158838', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('78', '1', 'wx1image_14751588393130.png', '/uploads/picture/2016-09-29/wx1image_14751588393130.png', '', 'local', 'picture', 'jpg', '', '10686', '', '', '', '0', '1475158839', '1475158839', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('79', '1', 'wx1image_1475158843730.png', '/uploads/picture/2016-09-29/wx1image_1475158843730.png', '', 'local', 'picture', 'jpg', '', '77934', '', '', '', '0', '1475158843', '1475158843', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('80', '1', 'wx1image_14751588431771.png', '/uploads/picture/2016-09-29/wx1image_14751588431771.png', '', 'local', 'picture', 'jpg', '', '38682', '', '', '', '0', '1475158843', '1475158843', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('81', '1', 'wx1image_14751588432055.png', '/uploads/picture/2016-09-29/wx1image_14751588432055.png', '', 'local', 'picture', 'jpg', '', '54928', '', '', '', '0', '1475158843', '1475158843', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('82', '1', 'wx1image_14751588441630.png', '/uploads/picture/2016-09-29/wx1image_14751588441630.png', '', 'local', 'picture', 'jpg', '', '22413', '', '', '', '0', '1475158844', '1475158844', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('83', '1', 'wx1image_14751588456818.png', '/uploads/picture/2016-09-29/wx1image_14751588456818.png', '', 'local', 'picture', 'jpg', '', '12567', '', '', '', '0', '1475158845', '1475158845', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('84', '1', 'wx1image_14751588548752.png', '/uploads/picture/2016-09-29/wx1image_14751588548752.png', '', 'local', 'picture', 'jpg', '', '86619', '', '', '', '0', '1475158854', '1475158854', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('85', '1', 'wx1image_14751588549711', '/uploads/picture/2016-09-29/wx1image_14751588549711.jpg', '', 'local', 'picture', 'jpg', '', '11863', '', '', '', '0', '1475158854', '1475158854', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('87', '1', 'wx1image_14751588668519', '/uploads/picture/2016-09-29/wx1image_14751588668519.jpg', '', 'local', 'picture', 'jpg', '', '27712', '', '', '', '0', '1475158866', '1475158866', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('88', '1', 'wx1image_14751588684053', '/uploads/picture/2016-09-29/wx1image_14751588684053.jpg', '', 'local', 'picture', 'jpg', '', '101186', '', '', '', '0', '1475158868', '1475158868', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('89', '1', 'wx1image_14751588703441', '/uploads/picture/2016-09-29/wx1image_14751588703441.jpg', '', 'local', 'picture', 'jpg', '', '155125', '', '', '', '0', '1475158870', '1475158870', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('90', '1', 'wx1image_14751588708117', '/uploads/picture/2016-09-29/wx1image_14751588708117.jpg', '', 'local', 'picture', 'jpg', '', '24226', '', '', '', '0', '1475158870', '1475158870', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('91', '1', 'meinv_admin_avatar', '/uploads/picture/2016-09-30/57edd952ba0e0.jpg', '', 'local', 'picture', 'jpg', '', '7006', '', '89b678fa35106c7a0f7579cb8426bd7a', '7d10ddb80359255e58c04bd30412b00bba6938a5', '0', '1475205458', '1475205458', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('92', '1', '57e0a9c03a61b', '/uploads/picture/2016-10-03/57f2076c4e997.jpg', '', 'local', 'picture', 'jpg', '', '110032', '', 'e3694c361707487802476e81709c863f', 'd5381f24235ee72d9fd8dfe2bb2e3d128217c8ce', '0', '1475479404', '1475479404', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('93', '1', '9812496129086622', '/uploads/picture/2016-10-06/57f6136b5bd4e.jpg', '', 'local', 'picture', 'jpg', '', '164177', '9812496129086622', '983944832c987b160ae409f71acc7933', 'bce6147f4070989fc0349798acf6383938e5563a', '0', '1475744619', '1475744619', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('94', '1', 'eacoophp-watermark-banner-1', 'http://cdn.eacoophp.com/static/demo-eacoophp/eacoophp-watermark-banner-1.jpg', 'http://cdn.eacoophp.com/static/demo-eacoophp/eacoophp-watermark-banner-1.jpg', 'link', 'picture', 'jpg', 'image', '171045', 'eacoophp-watermark-banner-1', '', '', '0', '1506215777', '1506215777', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('95', '1', 'eacoophp-banner-3', 'http://cdn.eacoophp.com/static/demo-eacoophp/eacoophp-banner-3.jpg', 'http://cdn.eacoophp.com/static/demo-eacoophp/eacoophp-banner-3.jpg', 'link', 'picture', 'jpg', 'image', '356040', 'eacoophp-banner-3', '', '', '0', '1506215801', '1506215801', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('96', '1', 'eacoophp-watermark-banner-2', 'http://cdn.eacoophp.com/static/demo-eacoophp/eacoophp-watermark-banner-2.jpg', 'http://cdn.eacoophp.com/static/demo-eacoophp/eacoophp-watermark-banner-2.jpg', 'link', 'picture', 'jpg', 'image', '356040', 'eacoophp-watermark-banner-2', '', '', '0', '1506215801', '1506215801', '99', '1');
INSERT INTO `eacoo_attachment` VALUES ('97', '1', '150217753092666', '/uploads/picture/2018-04-12/5acec2ffee8a4.jpg', '/uploads/picture/2018-04-12/5acec2ffee8a4.jpg', 'local', 'picture', 'jpg', 'image', '67406', '150217753092666', '82a25ea71fd7db1a2180894086790ea9', '87a03fe9161c0d3b4b757e999160355f9ce0ee75', '0', '1523499775', '1523499775', '99', '1');

-- -----------------------------
-- Table structure for `eacoo_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_auth_group`;
CREATE TABLE `eacoo_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) DEFAULT NULL COMMENT '描述信息',
  `rules` varchar(160) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态。1启用，0禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户组表';

-- -----------------------------
-- Records of `eacoo_auth_group`
-- -----------------------------
INSERT INTO `eacoo_auth_group` VALUES ('1', '超级管理员', '拥有网站的最高权限', '1,2,6,18,9,12,17,19,25,26,3,7,21,43,44,4,37,38,39,40,41,42,5,22,23,30,24,10,11,13,14,20,32,33,15,8,16,27,28,29', '1');
INSERT INTO `eacoo_auth_group` VALUES ('2', '管理员', '授权管理员', '1,6,18,12,19,26,3,7,21,44,4,37,38,39,40,41,42,5,22,23,30,24,10,11,13,14,20,15,8,16,27,28,29', '1');
INSERT INTO `eacoo_auth_group` VALUES ('3', '普通用户', '这是普通用户的权限', '1,3,8,10,11,94,95,96,97,98,99,41,42,43,44,38,39,40', '1');
INSERT INTO `eacoo_auth_group` VALUES ('4', '客服', '客服处理订单发货', '1,27,28,29,7,4,52,53,54,55', '1');

-- -----------------------------
-- Table structure for `eacoo_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_auth_group_access`;
CREATE TABLE `eacoo_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否审核  2：未审核，1:启用，0：禁用，-1：删除',
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户组明细表';

-- -----------------------------
-- Records of `eacoo_auth_group_access`
-- -----------------------------
INSERT INTO `eacoo_auth_group_access` VALUES ('1', '1', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('3', '3', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('4', '3', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('5', '3', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('6', '3', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('2', '1', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('7', '2', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('7', '3', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('7', '4', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('15', '2', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('14', '3', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('3', '4', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('5', '4', '1');
INSERT INTO `eacoo_auth_group_access` VALUES ('6', '4', '1');

-- -----------------------------
-- Table structure for `eacoo_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_auth_rule`;
CREATE TABLE `eacoo_auth_rule` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '' COMMENT '导航链接',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '导航名字',
  `depend_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '来源类型。1module，2plugin，3theme',
  `depend_flag` varchar(30) NOT NULL DEFAULT '' COMMENT '来源标记。如：模块或插件标识',
  `type` tinyint(1) DEFAULT '1' COMMENT '是否支持规则表达式',
  `pid` smallint(6) unsigned DEFAULT '0' COMMENT '上级id',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `condition` char(200) DEFAULT '',
  `is_menu` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否菜单',
  `position` varchar(20) DEFAULT 'left' COMMENT '菜单显示位置。left:左边，top:头部',
  `developer` tinyint(1) NOT NULL DEFAULT '0' COMMENT '开发者',
  `sort` smallint(6) unsigned DEFAULT '99' COMMENT '排序，值越小越靠前',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COMMENT='规则表（后台菜单）';

-- -----------------------------
-- Records of `eacoo_auth_rule`
-- -----------------------------
INSERT INTO `eacoo_auth_rule` VALUES ('1', 'admin/dashboard/index', '仪表盘', '1', 'admin', '1', '0', 'fa fa-tachometer', '', '1', 'left', '0', '1', '1519827783', '1507798445', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('2', 'admin', '系统设置', '1', 'admin', '1', '0', 'fa fa-cog', '', '1', 'left', '0', '2', '1507604200', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('3', 'user/user/', '用户管理', '1', 'user', '1', '0', 'fa fa-users', '', '1', 'left', '0', '5', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('4', 'admin/attachment/index', '附件空间', '1', 'admin', '1', '0', 'fa fa-picture-o', '', '1', 'left', '0', '7', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('5', 'admin/extend/index', '应用中心', '1', 'admin', '1', '0', 'fa fa-cloud', '', '1', 'left', '0', '11', '1507798466', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('6', 'admin/navigation/index', '前台导航菜单', '1', 'admin', '1', '2', 'fa fa-leaf', '', '1', 'left', '0', '6', '1516203955', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('7', 'user/user/index', '用户列表', '1', 'user', '1', '3', 'fa fa-user', '', '1', 'left', '0', '1', '1517981332', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('8', 'admin/auth/role', '角色组', '1', 'user', '1', '15', '', '', '1', 'left', '0', '1', '1506843587', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('9', 'admin/menu/index', '后台菜单管理', '1', 'admin', '1', '2', 'fa fa-inbox', '', '1', 'left', '1', '11', '1517902690', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('10', 'tools', '工具', '1', 'admin', '1', '0', 'fa fa-gavel', '', '1', 'left', '1', '9', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('11', 'admin/database', '安全', '1', 'admin', '1', '10', 'fa fa-database', '', '0', 'left', '0', '12', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('12', 'admin/attachment/setting', '设置', '1', 'admin', '1', '2', '', '', '0', 'left', '0', '0', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('13', 'admin/link/index', '友情链接', '1', 'admin', '1', '10', '', '', '1', 'left', '0', '6', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('14', 'admin/link/edit', '链接编辑', '1', 'admin', '1', '13', '', '', '0', 'left', '0', '1', '1519307879', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('15', 'user/auth', '权限管理', '1', 'user', '1', '0', 'fa fa-sun-o', '', '1', 'left', '0', '4', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('16', 'admin/auth/index', '规则管理', '1', 'admin', '1', '15', 'fa fa-500px', '', '1', 'left', '0', '2', '1520003985', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('17', 'admin/config/edit', '配置编辑或添加', '1', 'admin', '1', '2', '', '', '0', 'left', '0', '6', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('18', 'admin/navigation/edit', '导航编辑或添加', '1', 'admin', '1', '6', '', '', '0', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('19', 'admin/config/website', '网站设置', '1', 'admin', '1', '2', '', '', '1', 'left', '0', '4', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('20', 'admin/database/index', '数据库管理', '1', 'admin', '1', '10', 'fa fa-database', '', '1', 'left', '0', '13', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('21', 'user/user/resetPassword', '修改密码', '1', 'user', '1', '3', '', '', '1', 'top', '0', '99', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('22', 'admin/theme/index', '主题', '1', 'admin', '1', '5', 'fa fa-cloud', '', '1', 'left', '0', '3', '1518625223', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('23', 'admin/plugins/index', '插件', '1', 'admin', '1', '5', 'fa fa-cloud', '', '1', 'left', '0', '2', '1518625198', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('24', 'admin/modules/index', '模块', '1', 'admin', '1', '5', 'fa fa-cloud', '', '1', 'left', '0', '0', '1518625177', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('25', 'admin/config/index', '配置管理', '1', 'admin', '1', '2', '', '', '1', 'left', '1', '15', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('26', 'admin/config/group', '系统设置', '1', 'admin', '1', '2', '', '', '1', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('27', 'admin/action', '系统安全', '1', 'admin', '1', '0', 'fa fa-list-alt', '', '1', 'left', '0', '3', '1518678277', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('28', 'admin/action/index', '用户行为', '1', 'user', '1', '27', '', '', '1', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('29', 'admin/action/log', '行为日志', '1', 'user', '1', '27', 'fa fa-address-book-o', '', '1', 'left', '0', '2', '1518680430', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('30', 'admin/plugins/hooks', '钩子管理', '1', 'admin', '1', '23', '', '', '0', 'left', '1', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('32', 'admin/mailer/template', '邮件模板', '1', 'admin', '1', '10', '', '', '1', 'left', '0', '5', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('37', 'admin/attachment/attachmentCategory', '附件分类', '1', 'admin', '1', '4', '', '', '0', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('38', 'admin/attachment/upload', '文件上传', '1', 'admin', '1', '4', '', '', '0', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('39', 'admin/attachment/uploadPicture', '上传图片', '1', 'admin', '1', '4', '', '', '0', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('40', 'admin/attachment/upload_onlinefile', '添加外链附件', '1', 'admin', '1', '4', '', '', '0', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('41', 'admin/attachment/attachmentInfo', '附件详情', '1', 'admin', '1', '4', '', '', '0', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('42', 'admin/attachment/uploadAvatar', '上传头像', '1', 'admin', '1', '4', '', '', '0', 'left', '0', '1', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('43', 'user/tags/index', '标签管理', '1', 'user', '1', '3', '', '', '1', 'left', '0', '2', '1505816276', '1518796830', '0');
INSERT INTO `eacoo_auth_rule` VALUES ('44', 'user/tongji/analyze', '会员统计', '1', 'user', '1', '3', '', '', '1', 'left', '0', '4', '1505816276', '1518796830', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('45', 'cms/posts', '门户CMS', '1', 'cms', '1', '0', 'fa fa-file-text', '', '1', 'left', '0', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('46', 'admin/modules/config?name=cms', '模块设置', '1', 'cms', '1', '45', '', '', '1', 'left', '0', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('47', 'cms/Document/index', '文档管理', '1', 'cms', '1', '45', '', '', '1', 'left', '0', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('48', 'cms/posts/index', '文章列表', '1', 'cms', '1', '45', '', '', '1', 'left', '0', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('49', 'cms/posts/edit', '文章编辑', '1', 'cms', '1', '45', '', '', '0', 'left', '0', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('50', 'cms/category/index', '文章分类', '1', 'cms', '1', '45', '', '', '1', 'left', '0', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('51', 'cms/category/index?taxonomy=post_tag', '文章标签', '1', 'cms', '1', '45', '', '', '1', 'left', '0', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('52', 'cms/page/index', '页面列表', '1', 'cms', '1', '45', '', '', '1', 'left', '0', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_auth_rule` VALUES ('53', 'cms/posts/trash', '回收站', '1', 'cms', '1', '45', '', '', '1', 'left', '0', '99', '1537061246', '1537061246', '1');

-- -----------------------------
-- Table structure for `eacoo_config`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_config`;
CREATE TABLE `eacoo_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '配置名称',
  `title` varchar(50) NOT NULL COMMENT '配置说明',
  `value` text NOT NULL COMMENT '配置值',
  `options` varchar(255) NOT NULL COMMENT '配置额外值',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `sub_group` tinyint(3) DEFAULT '0' COMMENT '子分组，子分组需要自己定义',
  `type` varchar(16) NOT NULL DEFAULT '' COMMENT '配置类型',
  `remark` varchar(500) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '99' COMMENT '排序，值越小越靠前',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COMMENT='配置表';

-- -----------------------------
-- Records of `eacoo_config`
-- -----------------------------
INSERT INTO `eacoo_config` VALUES ('1', 'toggle_web_site', '站点开关', '1', '0:关闭\r\n1:开启', '1', '0', 'select', '站点关闭后将提示网站已关闭，不能正常访问', '1378898976', '1519825876', '1', '1');
INSERT INTO `eacoo_config` VALUES ('2', 'web_site_title', '网站标题', 'EacooPHP', '', '6', '0', 'text', '网站标题前台显示标题', '1378898976', '1507036190', '2', '1');
INSERT INTO `eacoo_config` VALUES ('4', 'web_site_logo', '网站LOGO', '4', '', '6', '0', 'picture', '网站LOGO', '1407003397', '1507036190', '4', '1');
INSERT INTO `eacoo_config` VALUES ('5', 'web_site_description', 'SEO描述', 'EacooPHP框架基于统一核心的通用互联网+信息化服务解决方案，追求简单、高效、卓越。可轻松实现支持多终端的WEB产品快速搭建、部署、上线。系统功能采用模块化、组件化、插件化等开放化低耦合设计，应用商城拥有丰富的功能模块、插件、主题，便于用户灵活扩展和二次开发。', '', '6', '1', 'textarea', '网站搜索引擎描述', '1378898976', '1506257875', '6', '1');
INSERT INTO `eacoo_config` VALUES ('6', 'web_site_keyword', 'SEO关键字', '开源框架 EacooPHP ThinkPHP', '', '6', '1', 'textarea', '网站搜索引擎关键字', '1378898976', '1506257874', '4', '1');
INSERT INTO `eacoo_config` VALUES ('7', 'web_site_copyright', '版权信息', 'Copyright © ******有限公司 All rights reserved.', '', '1', '0', 'text', '设置在网站底部显示的版权信息', '1406991855', '1468493911', '7', '1');
INSERT INTO `eacoo_config` VALUES ('8', 'web_site_icp', '网站备案号', '豫ICP备14003306号', '', '6', '0', 'text', '设置在网站底部显示的备案号，如“苏ICP备1502009-2号\"', '1378900335', '1507036190', '8', '1');
INSERT INTO `eacoo_config` VALUES ('9', 'web_site_statistics', '站点统计', '', '', '1', '0', 'textarea', '支持百度、Google、cnzz等所有Javascript的统计代码', '1378900335', '1415983236', '9', '1');
INSERT INTO `eacoo_config` VALUES ('10', 'index_url', '首页地址', 'https://www.eacoophp.com', '', '2', '0', 'text', '可以通过配置此项自定义系统首页的地址，比如：http://www.xxx.com', '1471579753', '1519825834', '0', '1');
INSERT INTO `eacoo_config` VALUES ('13', 'admin_tags', '后台多标签', '1', '0:关闭\r\n1:开启', '2', '0', 'radio', '', '1453445526', '1519825844', '3', '1');
INSERT INTO `eacoo_config` VALUES ('14', 'admin_page_size', '后台分页数量', '12', '', '2', '0', 'number', '后台列表分页时每页的记录数', '1434019462', '1518942039', '4', '1');
INSERT INTO `eacoo_config` VALUES ('15', 'admin_theme', '后台主题', 'default', 'default:默认主题\r\nblue:蓝色理想\r\ngreen:绿色生活', '2', '0', 'select', '后台界面主题', '1436678171', '1506099586', '5', '1');
INSERT INTO `eacoo_config` VALUES ('16', 'develop_mode', '开发模式', '1', '1:开启\r\n0:关闭', '3', '0', 'select', '开发模式下会显示菜单管理、配置管理、数据字典等开发者工具', '1432393583', '1507724972', '1', '1');
INSERT INTO `eacoo_config` VALUES ('17', 'app_trace', '是否显示页面Trace', '0', '1:开启\r\n0:关闭', '3', '0', 'select', '是否显示页面Trace信息', '1387165685', '1507724972', '2', '1');
INSERT INTO `eacoo_config` VALUES ('18', 'auth_key', '系统加密KEY', 'vzxI=vf[=xV)?a^XihbLKx?pYPw$;Mi^R*<mV;yJh$wy(~~E?<.JA&ANdIZ#QhPq', '', '3', '0', 'textarea', '轻易不要修改此项，否则容易造成用户无法登录；如要修改，务必备份原key', '1438647773', '1507724972', '3', '1');
INSERT INTO `eacoo_config` VALUES ('19', 'only_auth_rule', '权限仅验证规则表', '1', '1:开启\n0:关闭', '4', '0', 'radio', '开启此项，则后台验证授权只验证规则表存在的规则', '1473437355', '1473437355', '0', '1');
INSERT INTO `eacoo_config` VALUES ('20', 'static_domain', '静态文件独立域名', '', '', '3', '0', 'text', '静态文件独立域名一般用于在用户无感知的情况下平和的将网站图片自动存储到腾讯万象优图、又拍云等第三方服务。', '1438564784', '1438564784', '3', '1');
INSERT INTO `eacoo_config` VALUES ('21', 'config_group_list', '配置分组', '1:基本\r\n2:系统\r\n3:开发\r\n4:安全\r\n5:数据库\r\n6:网站设置\r\n7:用户\r\n8:邮箱\r\n9:高级', '', '3', '0', 'array', '配置分组的键值对不要轻易改变', '1379228036', '1518783085', '5', '1');
INSERT INTO `eacoo_config` VALUES ('25', 'form_item_type', '表单项目类型', 'hidden:隐藏\r\nreadonly:仅读文本\r\nnumber:数字\r\ntext:单行文本\r\ntextarea:多行文本\r\narray:数组\r\npassword:密码\r\nradio:单选框\r\ncheckbox:复选框\r\nselect:下拉框\r\nicon:字体图标\r\ndate:日期\r\ndatetime:时间\r\npicture:单张图片\r\npictures:多张图片\r\nfile:单个文件\r\nfiles:多个文件\r\nwangeditor:wangEditor编辑器\r\nueditor:百度富文本编辑器\r\neditormd:Markdown编辑器\r\ntags:标签\nselect2:高级下拉框\r\njson:JSON\r\nboard:拖', '', '3', '0', 'array', '专为配置管理设定\r\n', '1464533806', '1500174666', '0', '1');
INSERT INTO `eacoo_config` VALUES ('26', 'term_taxonomy', '分类法', 'post_category:分类目录\r\npost_tag:标签\r\nmedia_cat:多媒体分类', '', '3', '0', 'array', '', '1465267993', '1468421717', '0', '1');
INSERT INTO `eacoo_config` VALUES ('27', 'data_backup_path', '数据库备份根路径', '../data/backup', '', '5', '0', 'text', '', '1465478225', '1506099586', '0', '1');
INSERT INTO `eacoo_config` VALUES ('28', 'data_backup_part_size', '数据库备份卷大小', '20971520', '', '5', '0', 'number', '', '1465478348', '1506099586', '0', '1');
INSERT INTO `eacoo_config` VALUES ('29', 'data_backup_compress_level', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '5', '0', 'radio', '', '1465478496', '1506099586', '0', '1');
INSERT INTO `eacoo_config` VALUES ('30', 'data_backup_compress', '数据库备份文件压缩', '1', '0:不压缩\r\n1:启用压缩', '5', '0', 'radio', '', '1465478578', '1506099586', '0', '1');
INSERT INTO `eacoo_config` VALUES ('31', 'hooks_type', '钩子的类型', '1:视图\r\n2:控制器', '', '3', '0', 'array', '', '1465478697', '1465478697', '0', '1');
INSERT INTO `eacoo_config` VALUES ('33', 'action_type', '行为类型', '1:系统\r\n2:用户', '1:系统\r\n2:用户', '7', '0', 'array', '配置说明', '1466953086', '1466953086', '0', '1');
INSERT INTO `eacoo_config` VALUES ('34', 'website_group', '网站信息子分组', '0:基本信息\r\n1:SEO设置\r\n3:其它', '', '6', '0', 'array', '作为网站信息配置的子分组配置，每个大分组可设置子分组作为tab切换', '1467516762', '1518785115', '20', '1');
INSERT INTO `eacoo_config` VALUES ('36', 'mail_reg_active_template', '注册激活邮件模板', '{\"active\":\"0\",\"subject\":\"\\u6ce8\\u518c\\u6fc0\\u6d3b\\u901a\\u77e5\"}', '', '8', '0', 'json', 'JSON格式保存除了模板内容的属性', '1467519451', '1467519451', '0', '1');
INSERT INTO `eacoo_config` VALUES ('37', 'mail_captcha_template', '验证码邮件模板', '{\"active\":\"0\",\"subject\":\"\\u90ae\\u7bb1\\u9a8c\\u8bc1\\u7801\\u901a\\u77e5\"}', '', '8', '0', 'json', 'JSON格式保存除了模板内容的属性', '1467519582', '1467818456', '0', '1');
INSERT INTO `eacoo_config` VALUES ('38', 'mail_reg_active_template_content', '注册激活邮件模板内容', '<p><span style=\"font-family: 微软雅黑; font-size: 14px;\"></span><span style=\"font-family: 微软雅黑; font-size: 14px;\">您在{$title}的激活链接为</span><a href=\"{$url}\" target=\"_blank\" style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">激活</a><span style=\"font-family: 微软雅黑; font-size: 14px;\">，或者请复制链接：{$url}到浏览器打开。</span></p>', '', '8', '0', 'textarea', '注册激活模板邮件内容部分，模板内容单独存放', '1467818340', '1467818340', '0', '1');
INSERT INTO `eacoo_config` VALUES ('39', 'mail_captcha_template_content', '验证码邮件模板内容', '<p><span style=\"font-family: 微软雅黑; font-size: 14px;\">您的验证码为{$verify}验证码，账号为{$account}。</span></p>', '', '8', '0', 'textarea', '验证码邮件模板内容部分', '1467818435', '1467818435', '0', '1');
INSERT INTO `eacoo_config` VALUES ('40', 'attachment_options', '附件配置选项', '{\"driver\":\"local\",\"file_max_size\":\"2097152\",\"file_exts\":\"doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,zip,rar,gz,bz2,7z\",\"file_save_name\":\"uniqid\",\"image_max_size\":\"2097152\",\"image_exts\":\"gif,jpg,jpeg,bmp,png\",\"image_save_name\":\"uniqid\",\"page_number\":\"24\",\"widget_show_type\":\"0\",\"cut\":\"1\",\"small_size\":{\"width\":\"150\",\"height\":\"150\"},\"medium_size\":{\"width\":\"320\",\"height\":\"280\"},\"large_size\":{\"width\":\"560\",\"height\":\"430\"},\"watermark_scene\":\"2\",\"watermark_type\":\"1\",\"water_position\":\"9\",\"water_img\":\"\\/logo.png\",\"water_opacity\":\"80\"}', '', '9', '0', 'json', '以JSON格式保存', '1467858734', '1519804860', '0', '1');
INSERT INTO `eacoo_config` VALUES ('42', 'user_deny_username', '保留用户名和昵称', '管理员,测试,admin,垃圾', '', '7', '0', 'textarea', '禁止注册用户名和昵称，包含这些即无法注册,用&quot; , &quot;号隔开，用户只能是英文，下划线_，数字等', '1468493201', '1468493201', '0', '1');
INSERT INTO `eacoo_config` VALUES ('43', 'captcha_open', '验证码配置', 'reg,login,reset', 'reg:注册显示\r\nlogin:登陆显示\r\nreset:密码重置', '4', '0', 'checkbox', '验证码开启配置', '1468494419', '1506099586', '0', '1');
INSERT INTO `eacoo_config` VALUES ('44', 'captcha_type', '验证码类型', '4', '1:中文\r\n2:英文\r\n3:数字\r\n4:英文+数字', '4', '0', 'select', '验证码类型', '1468494591', '1506099586', '0', '1');
INSERT INTO `eacoo_config` VALUES ('45', 'web_site_subtitle', '网站副标题', '基于ThinkPHP5的开发框架', '', '6', '0', 'textarea', '用简洁的文字描述本站点（网站口号、宣传标语、一句话介绍）', '1468593713', '1507036190', '2', '1');
INSERT INTO `eacoo_config` VALUES ('46', 'cache', '缓存配置', '{\"type\":\"File\",\"path\":\"\\/Library\\/WebServer\\/Documents\\/EacooPHP\\/runtime\\/cache\\/\",\"prefix\":\"\",\"expire\":\"0\"}', '', '9', '0', 'json', '以JSON格式保存', '1518696015', '1518696015', '0', '1');
INSERT INTO `eacoo_config` VALUES ('47', 'session', 'Session配置', '{\"type\":\"\",\"prefix\":\"eacoophp_\",\"auto_start\":\"1\"}', '', '9', '0', 'json', '以JSON格式保存', '1518696015', '1518696015', '99', '1');
INSERT INTO `eacoo_config` VALUES ('48', 'cookie', 'Cookie配置', '{\"path\":\"\\/\",\"prefix\":\"eacoophp_\",\"expire\":\"0\",\"domain\":\"\",\"secure\":\"0\",\"httponly\":\"\",\"setcookie\":\"1\"}', '', '9', '0', 'json', '以JSON格式保存', '1518696015', '1518696015', '99', '1');
INSERT INTO `eacoo_config` VALUES ('49', 'reg_default_roleid', '注册默认角色', '4', '', '7', '0', 'select', '', '1471681620', '1471689765', '0', '1');
INSERT INTO `eacoo_config` VALUES ('50', 'open_register', '开放注册', '0', '1:是\r\n0:否', '7', '0', 'radio', '', '1471681674', '1471681674', '0', '1');
INSERT INTO `eacoo_config` VALUES ('56', 'meanwhile_user_online', '允许同时登录', '1', '1:是\r\n0:否', '7', '0', 'radio', '是否允许同一帐号在不同地方同时登录', '1473437355', '1473437355', '0', '1');
INSERT INTO `eacoo_config` VALUES ('57', 'admin_collect_menus', '后台收藏菜单', '{\"\\/admin.php\\/admin\\/attachment\\/setting.html\":{\"title\":\"\\u591a\\u5a92\\u4f53\\u8bbe\\u7f6e\"},\"\\/admin.php\\/admin\\/auth\\/index.html\":{\"title\":\"\\u89c4\\u5219\\u7ba1\\u7406\"},\"\\/admin.php\\/admin\\/modules\\/index.html\":{\"title\":\"\\u6a21\\u5757\\u5e02\\u573a\"},\"\\/admin.php\\/admin\\/dashboard\\/index.html\":{\"title\":\"\\u4eea\\u8868\\u76d8\"},\"\\/admin.php?s=\\/admin\\/action\\/index.html\":{\"title\":\"\\u7528\\u6237\\u884c\\u4e3a\"}}', '', '2', '0', 'json', '在后台顶部菜单栏展示，可以方便快速菜单入口', '1518629152', '1518629152', '99', '1');
INSERT INTO `eacoo_config` VALUES ('58', 'minify_status', '开启minify', '1', '1:开启\r\n0:关闭', '2', '0', 'radio', '开启minify会压缩合并js、css文件，可以减少资源请求次数，如果不支持minify，可关闭', '1518716395', '1518716395', '99', '1');
INSERT INTO `eacoo_config` VALUES ('59', 'admin_allow_login_many', '同账号多人登录后台', '0', '0:不允许\r\n1:允许', '4', '0', 'radio', '允许多个人使用同一个账号登录后台。默认：不允许', '1519785747', '1519785747', '99', '1');
INSERT INTO `eacoo_config` VALUES ('60', 'admin_allow_ip', '仅限登录后台IP', '', '', '4', '0', 'textarea', '填写IP地址，多个IP用英文逗号隔开。默认为空，允许所有IP', '1519828685', '1519828685', '99', '1');
INSERT INTO `eacoo_config` VALUES ('61', 'redis', 'Redis配置', '{\"host\":\"127.0.0.1\",\"port\":\"6979\"}', '', '9', '0', 'json', '以JSON格式保存', '1534347808', '1534347808', '99', '1');
INSERT INTO `eacoo_config` VALUES ('62', 'memcache', 'Memcache配置', '{\"host\":\"127.0.0.1\",\"port\":\"11211\"}', '', '9', '0', 'json', '以JSON格式保存', '1534347808', '1534347808', '99', '1');

-- -----------------------------
-- Table structure for `eacoo_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_hooks`;
CREATE TABLE `eacoo_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '钩子ID',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` varchar(300) NOT NULL DEFAULT '' COMMENT '描述',
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '类型。1视图，2控制器',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态。1启用，0禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COMMENT='钩子表';

-- -----------------------------
-- Records of `eacoo_hooks`
-- -----------------------------
INSERT INTO `eacoo_hooks` VALUES ('1', 'AdminIndex', '后台首页小工具', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('2', 'FormBuilderExtend', 'FormBuilder类型扩展Builder', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('3', 'UploadFile', '上传文件钩子', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('4', 'PageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('5', 'PageFooter', '页面footer钩子，一般用于加载插件CSS文件和代码', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('6', 'ThirdLogin', '第三方账号登陆', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('7', 'SendMessage', '发送消息钩子，用于消息发送途径的扩展', '2', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('8', 'sms', '短信插件钩子', '2', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('9', 'RegisterUser', '用户注册钩子', '2', '1523030193', '1523030193', '1');
INSERT INTO `eacoo_hooks` VALUES ('10', 'ImageGallery', '图片轮播钩子', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('11', 'JChinaCity', '每个系统都需要的一个中国省市区三级联动插件。', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('13', 'editor', '内容编辑器钩子', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('14', 'adminEditor', '后台内容编辑页编辑器', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('15', 'ThirdLogin', '集成第三方授权登录，包括微博、QQ、微信、码云', '1', '1518696015', '1518696015', '1');
INSERT INTO `eacoo_hooks` VALUES ('16', 'comment', '实现本地评论功能，支持评论点赞', '1', '1520776468', '1520776468', '1');
INSERT INTO `eacoo_hooks` VALUES ('17', 'uploadPicture', '实现阿里云OSS对象存储，管理附件', '1', '1523030193', '1523030193', '1');
INSERT INTO `eacoo_hooks` VALUES ('18', 'participle', '关键字提取，百度自然语言', '1', '1535955038', '1535955038', '1');
INSERT INTO `eacoo_hooks` VALUES ('19', 'MicroTopicsUserPost', '微话题，专注实时热点、个人兴趣、网友讨论等。', '1', '1536077536', '1536077536', '1');

-- -----------------------------
-- Table structure for `eacoo_hooks_extra`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_hooks_extra`;
CREATE TABLE `eacoo_hooks_extra` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hook_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '钩子ID',
  `depend_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '应用类型。1module，2plugin，3theme',
  `depend_flag` varchar(30) NOT NULL DEFAULT '' COMMENT '应用标记。如：模块或插件标识',
  `sort` smallint(6) unsigned NOT NULL DEFAULT '99' COMMENT '排序，值越小越靠前',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态。0禁用，1正常',
  PRIMARY KEY (`id`),
  KEY `idx_hookid_depend` (`hook_id`,`depend_flag`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='钩子应用依赖表';

-- -----------------------------
-- Records of `eacoo_hooks_extra`
-- -----------------------------
INSERT INTO `eacoo_hooks_extra` VALUES ('1', '1', '1', 'cms', '99', '1537061246', '1537061246', '1');

-- -----------------------------
-- Table structure for `eacoo_links`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_links`;
CREATE TABLE `eacoo_links` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `image` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '图标',
  `url` varchar(150) NOT NULL DEFAULT '' COMMENT '链接',
  `target` varchar(25) NOT NULL DEFAULT '_blank' COMMENT '打开方式',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '类型',
  `rating` int(11) unsigned NOT NULL COMMENT '评级',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态，1启用，0禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='友情链接表';

-- -----------------------------
-- Records of `eacoo_links`
-- -----------------------------
INSERT INTO `eacoo_links` VALUES ('1', 'EacooPHP官网', '96', 'https://www.eacoophp.com', '_blank', '2', '8', '1467863440', '1534736191', '2', '1');
INSERT INTO `eacoo_links` VALUES ('2', '社区', '89', 'https://forum.eacoophp.com', '_blank', '1', '9', '1465053539', '1534736234', '1', '1');

-- -----------------------------
-- Table structure for `eacoo_modules`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_modules`;
CREATE TABLE `eacoo_modules` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(31) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(63) NOT NULL DEFAULT '' COMMENT '标题',
  `description` varchar(127) NOT NULL DEFAULT '' COMMENT '描述',
  `author` varchar(31) NOT NULL DEFAULT '' COMMENT '开发者',
  `version` varchar(7) NOT NULL DEFAULT '' COMMENT '版本',
  `config` text NOT NULL COMMENT '配置',
  `is_system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许卸载',
  `url` varchar(120) DEFAULT NULL COMMENT '站点',
  `admin_manage_into` varchar(60) DEFAULT '' COMMENT '后台管理入口',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态。0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='模块功能表';

-- -----------------------------
-- Records of `eacoo_modules`
-- -----------------------------
INSERT INTO `eacoo_modules` VALUES ('1', 'user', '用户中心', '用户模块，系统核心模块，不可卸载', '心云间、凝听', '1.0.2', '', '1', 'https://www.eacoophp.com', '', '1520095970', '1520095970', '99', '1');
INSERT INTO `eacoo_modules` VALUES ('2', 'home', '前台Home', '一款基础前台Home模块', '心云间、凝听', '1.0.0', '', '1', '', '', '1520095970', '1520095970', '99', '1');
INSERT INTO `eacoo_modules` VALUES ('3', 'cms', '门户CMS', '门户网站、CMS、文章管理、页面管理', '心云间、凝听', '1.2.2', '{\"need_check\":\"0\",\"toggle_comment\":\"1\",\"taglib\":[\"cms\"],\"post_type\":[{\"name\":\"post\",\"title\":\"\\u6587\\u7ae0\"},{\"name\":\"page\",\"title\":\"\\u9875\\u9762\"},{\"name\":\"product\",\"title\":\"\\u4ea7\\u54c1\"}]}', '0', '', '', '1537061246', '1537061246', '99', '1');

-- -----------------------------
-- Table structure for `eacoo_nav`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_nav`;
CREATE TABLE `eacoo_nav` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL DEFAULT '' COMMENT '标题',
  `value` varchar(120) DEFAULT '' COMMENT 'url地址',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '父级',
  `position` varchar(20) NOT NULL DEFAULT '' COMMENT '位置。头部：header，我的：my',
  `target` varchar(15) DEFAULT '_self' COMMENT '打开方式。',
  `depend_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '来源类型。0普通外链http，1模块扩展，2插件扩展，3主题扩展',
  `depend_flag` varchar(30) NOT NULL DEFAULT '' COMMENT '来源标记。如：模块或插件标识',
  `icon` varchar(120) NOT NULL DEFAULT '' COMMENT '图标',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态。0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='前台导航';

-- -----------------------------
-- Records of `eacoo_nav`
-- -----------------------------
INSERT INTO `eacoo_nav` VALUES ('1', '主页', '/', '0', 'header', '_self', '1', 'home', 'fa fa-home', '10', '1517978360', '1516206948', '1');
INSERT INTO `eacoo_nav` VALUES ('2', '会员', 'user/index/index', '0', 'header', '_self', '1', 'user', '', '99', '1516245690', '1516245690', '1');
INSERT INTO `eacoo_nav` VALUES ('3', '下载', 'https://gitee.com/ZhaoJunfeng/EacooPHP/attach_files', '0', 'header', '_blank', '0', '', '', '99', '1516245884', '1516245884', '1');
INSERT INTO `eacoo_nav` VALUES ('4', '社区', 'https://forum.eacoophp.com', '0', 'header', '_blank', '0', '', '', '99', '1516246000', '1516246000', '1');
INSERT INTO `eacoo_nav` VALUES ('5', '文档', 'https://www.kancloud.cn/youpzt/eacoo', '0', 'header', '_blank', '0', '', '', '99', '1516249947', '1516249947', '1');
INSERT INTO `eacoo_nav` VALUES ('6', 'CMS门户', '', '0', 'header', '_self', '1', 'cms', '', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_nav` VALUES ('7', '文章列表', 'cms/Index/index', '6', 'header', '_self', '1', 'cms', 'fa fa-list', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_nav` VALUES ('8', '页面列表', 'cms/page/index', '6', 'header', '_self', '1', 'cms', 'fa fa-list', '99', '1537061246', '1537061246', '1');
INSERT INTO `eacoo_nav` VALUES ('9', '我的文章', 'cms/My/posts', '0', 'my', '_self', '1', 'cms', 'fa fa-list', '99', '1537061246', '1537061246', '1');

-- -----------------------------
-- Table structure for `eacoo_plugins`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_plugins`;
CREATE TABLE `eacoo_plugins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '插件名或标识',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text NOT NULL COMMENT '插件描述',
  `config` text COMMENT '配置',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `version` varchar(8) NOT NULL DEFAULT '' COMMENT '版本号',
  `admin_manage_into` varchar(60) DEFAULT '0' COMMENT '后台管理入口',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '插件类型',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='插件表';


-- -----------------------------
-- Table structure for `eacoo_postmeta`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_postmeta`;
CREATE TABLE `eacoo_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `idx_postid_metakey` (`post_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------
-- Table structure for `eacoo_posts`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_posts`;
CREATE TABLE `eacoo_posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL DEFAULT '0' COMMENT '标题',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '文章类型,post,page,product',
  `source` varchar(100) DEFAULT NULL COMMENT '来源',
  `excerpt` text COMMENT '摘要',
  `content` longtext NOT NULL COMMENT '内容',
  `author_id` int(11) unsigned NOT NULL COMMENT '作者',
  `seo_keywords` tinytext COMMENT 'seo_keywords',
  `img` int(11) unsigned DEFAULT '0' COMMENT '封面图片',
  `views` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数',
  `collection` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏量',
  `comment_count` int(11) unsigned DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'post的父级post id,表示post层级关系',
  `password` varchar(32) DEFAULT NULL,
  `fields` varchar(300) DEFAULT NULL COMMENT 'post的扩展字段，保存相关扩展属性，如缩略图；格式为json',
  `istop` tinyint(1) unsigned DEFAULT '0' COMMENT '置顶 1置顶； 0不置顶',
  `recommended` tinyint(1) DEFAULT '0' COMMENT '推荐 1推荐 0不推荐，大于1的数字可设定为不同推荐区',
  `publish_time` int(10) unsigned DEFAULT '0' COMMENT '发布时间',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(10) unsigned DEFAULT '99' COMMENT '排序号',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 -1 删除 0审核 1为已发布',
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_author_id` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='文章表';

-- -----------------------------
-- Records of `eacoo_posts`
-- -----------------------------
INSERT INTO `eacoo_posts` VALUES ('1', '揭秘eBay四大系统 从行为数据中寻找价值', '', 'post', '', '', '<p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 16px; color: rgb(102, 102, 102); font-family: \'Microsoft Yahei\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; white-space: normal;\">喜欢海淘的朋友应该对eBay并不陌生，如果你还不了解，可以把eBay+PayPal理解为淘宝+支付宝的组合，当然eBay不仅有C2C还有B2C的模式，甚至还有二手卖家。</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 16px; color: rgb(102, 102, 102); font-family: \'Microsoft Yahei\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; white-space: normal;\">铺垫了一些背景，我们再来说说电子商务，现在还有没网购过的同学请举手，1、2、3……可能没有几个。虽然大家都在各种电子商务网站上购过物，但是你是否知道你在网上的一切行为都已经被记录并进行分析。</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 16px; color: rgb(102, 102, 102); font-family: \'Microsoft Yahei\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; white-space: normal;\">不论国外还是国内的电子商务企业，他们的相同点都是以业务为导向。eBay的做法是用数据驱动商业，其上所有的数据产品都是针对业务而生，数据部门需要对不断变化的用户需求找到解决之法，也就是从客户的行为数据中来寻找价值。</p><h3 style=\"box-sizing: border-box; font-family: \'Microsoft Yahei\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: normal; line-height: 1.1; color: rgb(68, 68, 68); margin-top: 20px; margin-bottom: 16px; font-size: 16px; border-bottom-color: rgb(238, 238, 238); border-bottom-width: 1px; border-bottom-style: solid; padding-bottom: 0px; white-space: normal;\"><strong style=\"box-sizing: border-box;\">行为数据用混合的手段来处理</strong></h3><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 16px; color: rgb(102, 102, 102); font-family: \'Microsoft Yahei\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; white-space: normal;\">数据是eBay发展的基础和价值所在，所以eBay数据服务和解决方案团队从eBay成立的第一天就已经存在，从数据仓库到数据分析再到数据服务，部门的名字一直随着发展在不断变化。但万变不离其宗，数据服务和解决方案团队就是一个针对数据展开想象的部门。</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 16px; color: rgb(102, 102, 102); font-family: \'Microsoft Yahei\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; white-space: normal;\">eBay数据服务和解决方案团队分布在美国西雅图、圣何塞以及中国上海，而中国团队全职和外包人员总共将近有100人，其中有不同的职位和分工，包括数据科学家、数据工程师、商业需求分析师、产品经理四大类。两个区域的团队互相协作，共同开发核心数据的同时也支持不同的业务部门。</p><p><br/></p>', '1', '', '68', '0', '0', '0', '0', '', '', '0', '0', '1508063880', '1464081408', '1508063929', '99', '1');
INSERT INTO `eacoo_posts` VALUES ('2', '谷歌数据中心安全及设计的最佳实践', '', 'post', '', '', '<p>在首次云端平台使用者大会(Google Cloud Platform Global User Conference)上，谷歌的两位领导者——数据中心的运营副总裁Joe Kava和安全隐私方面的优秀工程师Niels Provos向与会者分享了谷歌在全球范围内设计、构建、运行和保护数据中心的实践方式，其中包含一些令谷歌的数据中心独一无二的秘诀，及其对于谷歌云端平台用户的意义。\r\n\r\n安全性和数据保护sdf\r\n\r\n谷歌一直以来将重心放在数据的安全和保护上，这也是我们的关键设计准则之一。在物理安全方面，我们以分层安全模型为特色，使用了如定制的电子访问卡、警报器、车辆进出限制、围栏架设、金属探测器及生物识别技术等保障措施。数据中心的地板配备了激光束入侵探测器，并安装了高清晰度的内外监视器，全天候检测追踪入侵行为。此外为以防万一，可随时调用访问日志、活动记录以及监控录像。\r\n\r\n同时数据中心还安排了经验丰富的保安人员每日例行巡逻，他们已接受过背景调查与严格的培训(可以点击查看数据中心的360度视频)。越靠近数据中心，安全措施系数就越高，只有一条安全通道能进入数据中心，通过安全徽章和生物识别技术来实现多重访问控制，只有特定职位的员工才有权进入。在整个谷歌公司，只有不到1%的员工曾踏足此区域。\r\n\r\n我们还采用了非常严格的点对点监管链，用于储存、追踪全过程——从第一次HD输入机器直至证实其已被销毁或清除。同时，我们采用了信息安全和物理安全双管齐下的方式，由于数据通过网络传输的特性，若未经授权可随意访问的话就会非常危险。有鉴于此，谷歌将数据传输过程中的信息保护摆在优先位置上，用户设备与谷歌间的数据传输通常都是利用HTTPS/TLS(安全传输层协议)来进行加密输送。谷歌是第一个默认启用HTTPS/TLS的主要云服务提供商。</p>', '1', '', '93', '0', '0', '0', '0', '', '', '0', '1', '1508063820', '1464081797', '1508063874', '99', '1');
INSERT INTO `eacoo_posts` VALUES ('3', '机器学习专家带你实践LSTM语言模型', '', 'post', '', '', '<p>测试</p><p><br></p>', '1', '', '94', '0', '0', '0', '0', '', '', '0', '0', '1508064480', '1464081899', '1508064489', '99', '1');
INSERT INTO `eacoo_posts` VALUES ('4', '大撒发送大撒发送', '', 'page', '', '', '<p style=\"text-align:center\"><br/></p><p>这是编辑的内容就gsadfasdfasfd</p><p></p>', '1', '', '1164', '0', '0', '0', '0', '', '', '0', '0', '0', '1464153628', '1506823903', '99', '-1');
INSERT INTO `eacoo_posts` VALUES ('5', '贝恩：企业大数据战略指南', '', 'post', '', '这是摘要dgs', '<p>企业大数据战略指南</p><p><br></p><p><img class=\"\" src=\"http://localhost/ZhaoCMF/Uploads/Picture/2016-09-26/57e8ddc3e1455.jpeg\" data-id=\"363\"></p><p>fsafsaf</p><p><br></p>', '1', '关键字1', '88', '0', '0', '0', '0', '', '', '1', '0', '1499913000', '1464791552', '1508071031', '99', '1');
INSERT INTO `eacoo_posts` VALUES ('6', '发撒范德萨', '', 'post', '', '', '<p>撒发达范德萨发送</p>', '1', '', '27', '0', '0', '0', '0', '', '', '0', '0', '1508064000', '0', '1508064154', '99', '1');
INSERT INTO `eacoo_posts` VALUES ('7', '关于我们', '', 'page', '', '', '<p>这是关于我们的内容，测试</p>', '1', '发达啊撒旦法撒发撒旦法按时', '', '0', '0', '0', '0', '', '', '0', '0', '', '1467857339', '1506824231', '99', '1');

-- -----------------------------
-- Table structure for `eacoo_rewrite`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_rewrite`;
CREATE TABLE `eacoo_rewrite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `rule` varchar(255) NOT NULL DEFAULT '' COMMENT '规则',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT 'url',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='伪静态表';


-- -----------------------------
-- Table structure for `eacoo_term_relationships`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_term_relationships`;
CREATE TABLE `eacoo_term_relationships` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'posts表里文章id',
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '分类id',
  `table` varchar(60) NOT NULL COMMENT '数据表',
  `uid` int(11) unsigned DEFAULT '0' COMMENT '分类与用户关系',
  `sort` int(10) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态，1发布，0不发布',
  PRIMARY KEY (`id`),
  KEY `idx_term_id` (`term_id`),
  KEY `idx_object_id` (`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='对象分类对应表';

-- -----------------------------
-- Records of `eacoo_term_relationships`
-- -----------------------------
INSERT INTO `eacoo_term_relationships` VALUES ('1', '95', '9', 'attachment', '1', '99', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('2', '94', '13', 'attachment', '1', '99', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('3', '116', '12', 'attachment', '1', '99', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('4', '92', '12', 'attachment', '1', '99', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('5', '70', '12', 'attachment', '1', '9', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('6', '93', '11', 'attachment', '1', '99', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('7', '96', '12', 'attachment', '1', '99', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('8', '3', '5', 'posts', '0', '0', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('9', '5', '6', 'posts', '0', '0', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('10', '2', '6', 'posts', '0', '0', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('11', '1', '6', 'posts', '0', '0', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('12', '4', '1', 'posts', '0', '0', '1');
INSERT INTO `eacoo_term_relationships` VALUES ('13', '6', '1', 'posts', '0', '0', '1');

-- -----------------------------
-- Table structure for `eacoo_terms`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_terms`;
CREATE TABLE `eacoo_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) NOT NULL COMMENT '分类名称',
  `slug` varchar(100) DEFAULT '' COMMENT '分类别名',
  `taxonomy` varchar(32) DEFAULT '' COMMENT '分类类型',
  `pid` int(10) unsigned DEFAULT '0' COMMENT '上级ID',
  `seo_title` varchar(128) DEFAULT '' COMMENT 'seo标题',
  `seo_keywords` varchar(255) DEFAULT '' COMMENT 'seo 关键词',
  `seo_description` varchar(255) DEFAULT '' COMMENT 'seo描述',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(10) unsigned DEFAULT '99' COMMENT '排序号',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态，1发布，0不发布',
  PRIMARY KEY (`term_id`),
  KEY `idx_taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='分类';

-- -----------------------------
-- Records of `eacoo_terms`
-- -----------------------------
INSERT INTO `eacoo_terms` VALUES ('1', '未分类', 'nocat', 'post_category', '0', '未分类', '', '自定义分类描述', '1516432626', '1516432626', '99', '1');
INSERT INTO `eacoo_terms` VALUES ('4', '大数据', 'tag_dashuju', 'post_tag', '0', '大数据', '', '这是标签描述', '1516432626', '1516432626', '99', '-1');
INSERT INTO `eacoo_terms` VALUES ('5', '技术类', 'technology', 'post_category', '0', '技术类', '关键词', '自定义分类描述', '1465570866', '1516430690', '99', '-1');
INSERT INTO `eacoo_terms` VALUES ('7', '运营', 'yunying', 'post_tag', '0', '运营', '关键字', '自定义标签描述', '1466612937', '1516432746', '99', '1');
INSERT INTO `eacoo_terms` VALUES ('9', '人物', 'renwu', 'media_cat', '0', '人物', '', '聚集多为人物显示的分类', '1466613381', '1532584734', '99', '1');
INSERT INTO `eacoo_terms` VALUES ('10', '美食', 'meishi', 'media_cat', '0', '美食', '', '', '1466613499', '1532584725', '99', '1');
INSERT INTO `eacoo_terms` VALUES ('11', '图标素材', 'icons', 'media_cat', '0', '图标素材', '', '', '1466613803', '1522951971', '99', '1');
INSERT INTO `eacoo_terms` VALUES ('12', '风景', 'fengjin', 'media_cat', '0', '风景', '风景', '', '1466614026', '1506557501', '99', '1');
INSERT INTO `eacoo_terms` VALUES ('13', '其它', 'others', 'media_cat', '0', '其它', '', '', '1467689719', '1519814576', '99', '1');

-- -----------------------------
-- Table structure for `eacoo_themes`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_themes`;
CREATE TABLE `eacoo_themes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '标题',
  `description` varchar(127) NOT NULL DEFAULT '' COMMENT '描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '开发者',
  `version` varchar(8) NOT NULL DEFAULT '' COMMENT '版本',
  `config` text COMMENT '主题配置',
  `current` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '当前主题类型，1PC端，2手机端。默认0',
  `website` varchar(120) DEFAULT '' COMMENT '站点',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='前台主题表';

-- -----------------------------
-- Records of `eacoo_themes`
-- -----------------------------
INSERT INTO `eacoo_themes` VALUES ('1', 'default', '默认主题', '内置于系统中，是其它主题的基础主题', '心云间、凝听', '1.0.2', '', '0', 'https://www.eacoophp.com', '99', '1475899420', '1520090170', '1');
INSERT INTO `eacoo_themes` VALUES ('2', 'default-mobile', '默认主题-手机端', '内置于系统中，是系统的默认主题。手机端', '心云间、凝听', '1.0.1', '', '2', '', '99', '1520089999', '1520092270', '1');
INSERT INTO `eacoo_themes` VALUES ('3', 'acg-no-1', 'ACG-No.1', 'ACG-No.1二次元博客主题,针对CMS做单独优化处理', 'yyyvy', '1.0.0', '', '1', '', '99', '1537061258', '1537061258', '1');

-- -----------------------------
-- Table structure for `eacoo_users`
-- -----------------------------
DROP TABLE IF EXISTS `eacoo_users`;
CREATE TABLE `eacoo_users` (
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名',
  `number` char(10) DEFAULT '' COMMENT '会员编号',
  `password` char(32) NOT NULL DEFAULT '' COMMENT '登录密码',
  `nickname` varchar(60) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '登录邮箱',
  `mobile` varchar(20) DEFAULT '' COMMENT '手机号',
  `avatar` varchar(150) DEFAULT '' COMMENT '用户头像，相对于uploads/avatar目录',
  `sex` smallint(1) unsigned DEFAULT '0' COMMENT '性别；0：保密，1：男；2：女',
  `birthday` date DEFAULT '0000-00-00' COMMENT '生日',
  `description` varchar(200) DEFAULT '' COMMENT '个人描述',
  `register_ip` varchar(16) DEFAULT '' COMMENT '注册IP',
  `login_num` tinyint(1) unsigned DEFAULT '0' COMMENT '登录次数',
  `last_login_ip` varchar(16) DEFAULT '' COMMENT '最后登录ip',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `activation_auth_sign` varchar(60) DEFAULT '' COMMENT '激活码',
  `url` varchar(100) DEFAULT '' COMMENT '用户个人网站',
  `score` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户积分',
  `money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '金额',
  `freeze_money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '冻结金额，和金币相同换算',
  `pay_pwd` char(32) DEFAULT '' COMMENT '支付密码',
  `reg_from` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '注册来源。1PC端，2WAP端，3微信端，4APP端，5后台添加',
  `reg_method` varchar(30) NOT NULL DEFAULT '' COMMENT '注册方式。wechat,sina,等',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `p_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '推荐人会员ID',
  `allow_admin` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '允许后台。0不允许，1允许',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '2' COMMENT '用户状态 0：禁用； 1：正常 ；2：待验证',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `uniq_number` (`number`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `eacoo_users`
-- -----------------------------
INSERT INTO `eacoo_users` VALUES ('1', 'admin', '5257975351', '031c9ffc4b280d3e78c750163d07d275', '创始人', '981248356@qq.com', '15801182251', 'http://www.eacoo-php.org/static/assets/img/default-avatar.png', '1', '', '网站创始人和超级管理员。', '', '0', '127.0.0.1', '1537285090', '5410273c9136c5c6252eac5c5e03a11ad5f38b71', 'http://www.eacoo123.com', '1770', '7113.36', '0.00', 'eba6095468eb32492d20d5db6a85aa5d', '0', '', '0', '0', '1', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('3', 'U1471610993', '9948511005', '031c9ffc4b280d3e78c750163d07d275', '陈婧', '', '', '/static/assets/img/avatar-woman.png', '2', '', '', '', '0', '', '1473755335', 'a525c9259ff2e51af1b6e629dd47766f99f26c69', '', '0', '2.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('4', 'U1472438063', '9752985498', '031c9ffc4b280d3e78c750163d07d275', '妍冰', '', '', '/static/assets/img/avatar-woman.png', '2', '', '承接大型商业演出和传统文化学习班', '', '0', '', '1472438634', 'ed587cf103c3f100be20f7b8fdc7b5a8e2fda264', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('5', 'U1472522409', '9849571025', '031c9ffc4b280d3e78c750163d07d275', '久柳', '', '', '/static/assets/img/avatar-man.png', '1', '', '', '', '0', '', '1472522621', '5e542dc0c77b3749f2270cb3ec1d91acc895edc8', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '2');
INSERT INTO `eacoo_users` VALUES ('6', 'U1472739566', '5051101100', '031c9ffc4b280d3e78c750163d07d275', 'Ray', '', '', '/uploads/avatar/6/5a8ada8f72ac0.jpg', '1', '', '', '', '0', '', '1472739567', '6321b4d8ecb1ce1049eab2be70c44335856c840d', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '1', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('8', 'U1472877421', '5497481009', '031c9ffc4b280d3e78c750163d07d275', '印文博律师', '', '', '/static/assets/img/avatar-man.png', '1', '', '', '', '0', '', '1473494692', 'e99521af40a282e84718f759ab6b1b4a989d8eb1', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('9', 'U1472966655', '1004810149', '031c9ffc4b280d3e78c750163d07d275', '嘉伟', '', '', '/static/assets/img/avatar-man.png', '1', '', '', '', '0', '', '1473397571', 'f1075223be5f53b9c2c1abea8288258545365d96', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('10', 'U1473304718', '9852101101', '031c9ffc4b280d3e78c750163d07d275', '鬼谷学猛虎流', '', '15801182191', '/static/assets/img/avatar-man.png', '1', '', '', '', '0', '', '1473399843', '039fc7a3f9366adf55ee9e707c371a2459c17bd7', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('11', 'U1473391063', '1004810150', '031c9ffc4b280d3e78c750163d07d275', '@Gyb.', '', '', '/uploads/avatar/11/59e32aa3a75a2.jpg', '1', '', '', '', '0', '', '1473391063', '70d80a9f7599c81270a986abaea73e63101b3ecb', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('12', 'U1473396778', '5310148501', '031c9ffc4b280d3e78c750163d07d275', '董超楠', '', '', '/static/assets/img/avatar-woman.png', '2', '', '', '', '0', '', '1473396778', '8bbf5242300e5e8e4917b287a31efcb0c9feedfd', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('14', 'U1473396839', '4853979757', '031c9ffc4b280d3e78c750163d07d275', '求真实者', '', '', '/static/assets/img/default-avatar.png', '0', '', '', '', '0', '', '1473396839', '8f7579a85981e1c1f726704b0865320dfadbef2e', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('15', 'U1473397391', '9810148101', '031c9ffc4b280d3e78c750163d07d275', 'peter', '', '', '/uploads/avatar/15/5a9d1473d4c91.png', '2', '', '', '', '0', '', '1473397391', 'c66d3a0e16a81a13173756a2832ba424b34a095c', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('16', 'U1473397426', '1015057995', '031c9ffc4b280d3e78c750163d07d275', '随风而去的心情', '', '15801182190', '/static/assets/img/avatar-man.png', '1', '', '大师傅', '', '0', '', '1473397426', '14855b00775de46b451c8255e6a73a5c044fc188', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
INSERT INTO `eacoo_users` VALUES ('17', 'U1474181145', '5551564851', '031c9ffc4b280d3e78c750163d07d275', '班鱼先生', '', '', '/static/assets/img/avatar-man.png', '1', '', '', '', '0', '', '1474181146', '86d19a7b1f15db4fd25e0b64bfc17870a70f67e2', '', '0', '0.00', '0.00', '', '0', '', '0', '0', '0', '1518696015', '1');
